package com.example.solarsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiSolarSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
