package com.example.solarsystem.service;

import com.example.solarsystem.dto.MoonDto;
import com.example.solarsystem.entity.Moon;
import com.example.solarsystem.entity.Planet;
import com.example.solarsystem.exception.BadRequestException;
import com.example.solarsystem.exception.ResourceNotFoundException;
import com.example.solarsystem.repository.MoonRepository;
import com.example.solarsystem.repository.PlanetRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class MoonService {

    private final MoonRepository moonRepository;
    private final PlanetRepository planetRepository;

    @Transactional
    public MoonDto createMoon(MoonDto moonDto) {
        log.info("Creating new moon: {}", moonDto.getName());

        // Ensure the linked planet exists
        Planet planet = planetRepository.findById(moonDto.getPlanetId())
                .orElseThrow(() -> new BadRequestException("Planet not found with id: " + moonDto.getPlanetId()));

        Moon moon = mapToEntity(moonDto, planet);
        Moon savedMoon = moonRepository.save(moon);
        return mapToDto(savedMoon);
    }

    @Transactional(readOnly = true)
    public List<MoonDto> getAllMoons() {
        log.info("Fetching all moons");
        return moonRepository.findAll().stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public MoonDto getMoonById(Long id) {
        log.info("Fetching moon with id: {}", id);
        Moon moon = moonRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Moon not found with id: " + id));
        return mapToDto(moon);
    }

    @Transactional
    public void deleteMoon(Long id) {
        log.info("Deleting moon with id: {}", id);
        if (!moonRepository.existsById(id)) {
            throw new ResourceNotFoundException("Moon not found with id: " + id);
        }
        moonRepository.deleteById(id);
    }

    @Transactional(readOnly = true)
    public List<MoonDto> getMoonsByPlanetName(String planetName) {
        log.info("Fetching moons by planet name: {}", planetName);
        return moonRepository.findMoonsByPlanetName(planetName).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public Long countMoonsByPlanetId(Long planetId) {
        log.info("Counting moons for planet id: {}", planetId);
        // Verify planet exists
        if (!planetRepository.existsById(planetId)) {
            throw new ResourceNotFoundException("Planet not found with id: " + planetId);
        }
        return moonRepository.countMoonsByPlanetId(planetId);
    }

    // Mapper methods
    private MoonDto mapToDto(Moon moon) {
        MoonDto dto = new MoonDto();
        dto.setMoonId(moon.getMoonId());
        dto.setName(moon.getName());
        dto.setDiameterKm(moon.getDiameterKm());
        dto.setOrbitalPeriodDays(moon.getOrbitalPeriodDays());
        dto.setPlanetId(moon.getPlanet().getPlanetId());
        dto.setPlanetName(moon.getPlanet().getName());
        return dto;
    }

    private Moon mapToEntity(MoonDto dto, Planet planet) {
        Moon moon = new Moon();
        moon.setName(dto.getName());
        moon.setDiameterKm(dto.getDiameterKm());
        moon.setOrbitalPeriodDays(dto.getOrbitalPeriodDays());
        moon.setPlanet(planet);
        return moon;
    }
}