package com.example.solarsystem.controller;

import com.example.solarsystem.dto.PlanetDto;
import com.example.solarsystem.dto.PlanetProjection;
import com.example.solarsystem.service.PlanetService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/planets")
@RequiredArgsConstructor
@Tag(name = "Planet Management", description = "APIs for managing planets")
@SecurityRequirement(name = "basicAuth")
public class PlanetController {

    private final PlanetService planetService;

    @PostMapping
    @PreAuthorize("hasAnyRole('STAFF', 'ADMIN')")
    @Operation(summary = "Add a new planet", description = "Create a new planet (STAFF/ADMIN only)")
    public ResponseEntity<PlanetDto> createPlanet(@Valid @RequestBody PlanetDto planetDto) {
        PlanetDto created = planetService.createPlanet(planetDto);
        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('STUDENT', 'STAFF', 'ADMIN')")
    @Operation(summary = "Get all planets", description = "Retrieve all planets")
    public ResponseEntity<List<PlanetDto>> getAllPlanets() {
        List<PlanetDto> planets = planetService.getAllPlanets();
        return ResponseEntity.ok(planets);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('STUDENT', 'STAFF', 'ADMIN')")
    @Operation(summary = "Get planet by ID", description = "Retrieve a planet by its ID")
    public ResponseEntity<PlanetDto> getPlanetById(@PathVariable Long id) {
        PlanetDto planet = planetService.getPlanetById(id);
        return ResponseEntity.ok(planet);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('STAFF', 'ADMIN')")
    @Operation(summary = "Update planet", description = "Update planet details (STAFF/ADMIN only)")
    public ResponseEntity<PlanetDto> updatePlanet(@PathVariable Long id, @Valid @RequestBody PlanetDto planetDto) {
        PlanetDto updated = planetService.updatePlanet(id, planetDto);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('STAFF', 'ADMIN')")
    @Operation(summary = "Delete planet", description = "Remove a planet by ID (STAFF/ADMIN only)")
    public ResponseEntity<Void> deletePlanet(@PathVariable Long id) {
        planetService.deletePlanet(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/type/{type}")
    @PreAuthorize("hasAnyRole('STUDENT', 'STAFF', 'ADMIN')")
    @Operation(summary = "Get planets by type", description = "Retrieve planets by their type")
    public ResponseEntity<List<PlanetDto>> getPlanetsByType(@PathVariable String type) {
        List<PlanetDto> planets = planetService.getPlanetsByType(type);
        return ResponseEntity.ok(planets);
    }

    @GetMapping("/projection")
    @PreAuthorize("hasAnyRole('STUDENT', 'STAFF', 'ADMIN')")
    @Operation(summary = "Get planet projections", description = "Retrieve specific fields (name and mass) of all planets using JPA projection")
    public ResponseEntity<List<PlanetProjection>> getPlanetsProjection() {
        List<PlanetProjection> projections = planetService.getPlanetsProjection();
        return ResponseEntity.ok(projections);
    }
}