package com.example.solarsystem.graphql.input;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserInput {
    private String username;
    private String password;
    private String role; // ADMIN, STAFF, STUDENT
    private Boolean enabled;
}