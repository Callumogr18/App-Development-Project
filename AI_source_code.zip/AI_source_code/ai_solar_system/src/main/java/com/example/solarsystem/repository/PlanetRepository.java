package com.example.solarsystem.repository;

import com.example.solarsystem.dto.PlanetProjection;
import com.example.solarsystem.entity.Planet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PlanetRepository extends JpaRepository<Planet, Long> {

    /**
     * Find planets by type
     */
    List<Planet> findByType(String type);

    /**
     * Find planet by name
     */
    Optional<Planet> findByName(String name);

    /**
     * Custom JPA Projection to retrieve only name and mass_kg fields
     */
    @Query("SELECT p.name as name, p.massKg as massKg FROM Planet p")
    List<PlanetProjection> findAllProjectedBy();
}