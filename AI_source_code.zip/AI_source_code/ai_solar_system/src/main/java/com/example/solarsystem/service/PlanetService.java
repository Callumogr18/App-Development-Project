package com.example.solarsystem.service;

import com.example.solarsystem.dto.PlanetDto;
import com.example.solarsystem.dto.PlanetProjection;
import com.example.solarsystem.entity.Planet;
import com.example.solarsystem.exception.BadRequestException;
import com.example.solarsystem.exception.ResourceNotFoundException;
import com.example.solarsystem.repository.PlanetRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class PlanetService {

    private final PlanetRepository planetRepository;

    @Transactional
    public PlanetDto createPlanet(PlanetDto planetDto) {
        log.info("Creating new planet: {}", planetDto.getName());

        // Check if planet already exists
        if (planetRepository.findByName(planetDto.getName()).isPresent()) {
            throw new BadRequestException("Planet with name " + planetDto.getName() + " already exists");
        }

        Planet planet = mapToEntity(planetDto);
        Planet savedPlanet = planetRepository.save(planet);
        return mapToDto(savedPlanet);
    }

    @Transactional(readOnly = true)
    public List<PlanetDto> getAllPlanets() {
        log.info("Fetching all planets");
        return planetRepository.findAll().stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public PlanetDto getPlanetById(Long id) {
        log.info("Fetching planet with id: {}", id);
        Planet planet = planetRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Planet not found with id: " + id));
        return mapToDto(planet);
    }

    @Transactional
    public PlanetDto updatePlanet(Long id, PlanetDto planetDto) {
        log.info("Updating planet with id: {}", id);
        Planet planet = planetRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Planet not found with id: " + id));

        planet.setName(planetDto.getName());
        planet.setType(planetDto.getType());
        planet.setRadiusKm(planetDto.getRadiusKm());
        planet.setMassKg(planetDto.getMassKg());
        planet.setOrbitalPeriodDays(planetDto.getOrbitalPeriodDays());

        Planet updatedPlanet = planetRepository.save(planet);
        return mapToDto(updatedPlanet);
    }

    @Transactional
    public void deletePlanet(Long id) {
        log.info("Deleting planet with id: {}", id);
        if (!planetRepository.existsById(id)) {
            throw new ResourceNotFoundException("Planet not found with id: " + id);
        }
        planetRepository.deleteById(id);
    }

    @Transactional(readOnly = true)
    public List<PlanetDto> getPlanetsByType(String type) {
        log.info("Fetching planets by type: {}", type);
        return planetRepository.findByType(type).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<PlanetProjection> getPlanetsProjection() {
        log.info("Fetching planets projection (name and mass)");
        return planetRepository.findAllProjectedBy();
    }

    // Mapper methods
    private PlanetDto mapToDto(Planet planet) {
        PlanetDto dto = new PlanetDto();
        dto.setPlanetId(planet.getPlanetId());
        dto.setName(planet.getName());
        dto.setType(planet.getType());
        dto.setRadiusKm(planet.getRadiusKm());
        dto.setMassKg(planet.getMassKg());
        dto.setOrbitalPeriodDays(planet.getOrbitalPeriodDays());
        return dto;
    }

    private Planet mapToEntity(PlanetDto dto) {
        Planet planet = new Planet();
        planet.setName(dto.getName());
        planet.setType(dto.getType());
        planet.setRadiusKm(dto.getRadiusKm());
        planet.setMassKg(dto.getMassKg());
        planet.setOrbitalPeriodDays(dto.getOrbitalPeriodDays());
        return planet;
    }
}