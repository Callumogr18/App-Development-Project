package com.example.solarsystem.enums;

public enum UserRole {
    ADMIN,
    STAFF,
    STUDENT
}