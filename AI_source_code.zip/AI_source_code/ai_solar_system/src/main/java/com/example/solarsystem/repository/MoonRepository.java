package com.example.solarsystem.repository;

import com.example.solarsystem.entity.Moon;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MoonRepository extends JpaRepository<Moon, Long> {

    /**
     * Custom JPA Query to find moons by planet name
     */
    @Query("SELECT m FROM Moon m WHERE m.planet.name = :planetName")
    List<Moon> findMoonsByPlanetName(@Param("planetName") String planetName);

    /**
     * Custom aggregate JPA Query to count moons for a specific planet ID
     */
    @Query("SELECT COUNT(m) FROM Moon m WHERE m.planet.planetId = :planetId")
    Long countMoonsByPlanetId(@Param("planetId") Long planetId);
}