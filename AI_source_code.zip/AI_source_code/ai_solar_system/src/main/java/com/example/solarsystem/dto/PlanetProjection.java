package com.example.solarsystem.dto;

/**
 * Custom JPA Projection interface for retrieving specific Planet fields
 */
public interface PlanetProjection {
    String getName();
    Double getMassKg();
}