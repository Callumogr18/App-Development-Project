package com.example.solarsystem.graphql;

import com.example.solarsystem.entity.User;
import com.example.solarsystem.graphql.input.UserInput;
import com.example.solarsystem.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;

@Controller
@RequiredArgsConstructor
public class UserGraphQLController {

    private final UserService userService;

    @QueryMapping
    @PreAuthorize("hasRole('ADMIN')")
    public User findUserById(@Argument Long id) {
        return userService.findUserById(id);
    }

    @MutationMapping
    @PreAuthorize("hasRole('ADMIN')")
    public User createUser(@Argument UserInput userInput) {
        return userService.createUser(
                userInput.getUsername(),
                userInput.getPassword(),
                userInput.getRole(),
                userInput.getEnabled()
        );
    }
}