package com.example.solarsystem.controller;

import com.example.solarsystem.dto.MoonDto;
import com.example.solarsystem.service.MoonService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/moons")
@RequiredArgsConstructor
@Tag(name = "Moon Management", description = "APIs for managing moons")
@SecurityRequirement(name = "basicAuth")
public class MoonController {

    private final MoonService moonService;

    @PostMapping
    @PreAuthorize("hasAnyRole('STAFF', 'ADMIN')")
    @Operation(summary = "Add a new moon", description = "Create a new moon linked to a planet (STAFF/ADMIN only)")
    public ResponseEntity<MoonDto> createMoon(@Valid @RequestBody MoonDto moonDto) {
        MoonDto created = moonService.createMoon(moonDto);
        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('STUDENT', 'STAFF', 'ADMIN')")
    @Operation(summary = "Get all moons", description = "Retrieve all moons")
    public ResponseEntity<List<MoonDto>> getAllMoons() {
        List<MoonDto> moons = moonService.getAllMoons();
        return ResponseEntity.ok(moons);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('STUDENT', 'STAFF', 'ADMIN')")
    @Operation(summary = "Get moon by ID", description = "Retrieve a moon by its ID")
    public ResponseEntity<MoonDto> getMoonById(@PathVariable Long id) {
        MoonDto moon = moonService.getMoonById(id);
        return ResponseEntity.ok(moon);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('STAFF', 'ADMIN')")
    @Operation(summary = "Delete moon", description = "Remove a moon by ID (STAFF/ADMIN only)")
    public ResponseEntity<Void> deleteMoon(@PathVariable Long id) {
        moonService.deleteMoon(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/by-planet/{planetName}")
    @PreAuthorize("hasAnyRole('STUDENT', 'STAFF', 'ADMIN')")
    @Operation(summary = "Get moons by planet name", description = "List moons by planet name using custom JPA query")
    public ResponseEntity<List<MoonDto>> getMoonsByPlanetName(@PathVariable String planetName) {
        List<MoonDto> moons = moonService.getMoonsByPlanetName(planetName);
        return ResponseEntity.ok(moons);
    }

    @GetMapping("/count/{planetId}")
    @PreAuthorize("hasAnyRole('STUDENT', 'STAFF', 'ADMIN')")
    @Operation(summary = "Count moons by planet", description = "Count the number of moons for a specific planet using aggregate JPA query")
    public ResponseEntity<Long> countMoonsByPlanetId(@PathVariable Long planetId) {
        Long count = moonService.countMoonsByPlanetId(planetId);
        return ResponseEntity.ok(count);
    }
}