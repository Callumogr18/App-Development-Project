package com.example.solarsystem.aspect;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Aspect
@Component
@Slf4j
public class LoggingAspect {

    /**
     * Pointcut 1: Log all controller method executions
     * Logs entry and exit of all REST controller methods
     */
    @Pointcut("execution(* com.example.solarsystem.controller..*(..))")
    public void controllerMethods() {}

    @Before("controllerMethods()")
    public void logBeforeController(JoinPoint joinPoint) {
        String methodName = joinPoint.getSignature().toShortString();
        Object[] args = joinPoint.getArgs();
        log.info("==> Controller Method Called: {} with arguments: {}", methodName, Arrays.toString(args));
    }

    @AfterReturning(pointcut = "controllerMethods()", returning = "result")
    public void logAfterController(JoinPoint joinPoint, Object result) {
        String methodName = joinPoint.getSignature().toShortString();
        log.info("<== Controller Method Completed: {} returned: {}", methodName, result);
    }

    /**
     * Pointcut 2: Log all service layer method executions with execution time
     * Measures and logs the time taken by service methods
     */
    @Pointcut("execution(* com.example.solarsystem.service..*(..))")
    public void serviceMethods() {}

    @Around("serviceMethods()")
    public Object logAroundService(ProceedingJoinPoint joinPoint) throws Throwable {
        String methodName = joinPoint.getSignature().toShortString();
        long startTime = System.currentTimeMillis();

        log.info(">>> Service Method Starting: {}", methodName);

        Object result;
        try {
            result = joinPoint.proceed();
            long endTime = System.currentTimeMillis();
            long executionTime = endTime - startTime;
            log.info("<<< Service Method Finished: {} in {} ms", methodName, executionTime);
        } catch (Exception e) {
            long endTime = System.currentTimeMillis();
            long executionTime = endTime - startTime;
            log.error("<<< Service Method Failed: {} after {} ms with exception: {}",
                    methodName, executionTime, e.getMessage());
            throw e;
        }

        return result;
    }

    /**
     * Pointcut 3: Log all repository method executions
     * Logs database operations performed by repositories
     */
    @Pointcut("execution(* com.example.solarsystem.repository..*(..))")
    public void repositoryMethods() {}

    @Before("repositoryMethods()")
    public void logBeforeRepository(JoinPoint joinPoint) {
        String methodName = joinPoint.getSignature().toShortString();
        Object[] args = joinPoint.getArgs();
        log.debug("[DB] Repository Query Executing: {} with parameters: {}", methodName, Arrays.toString(args));
    }

    @AfterReturning(pointcut = "repositoryMethods()", returning = "result")
    public void logAfterRepository(JoinPoint joinPoint, Object result) {
        String methodName = joinPoint.getSignature().toShortString();
        if (result != null) {
            log.debug("[DB] Repository Query Completed: {} returned {} result(s)",
                    methodName, result.toString().length() > 50 ? "data" : result);
        } else {
            log.debug("[DB] Repository Query Completed: {} returned null", methodName);
        }
    }

    /**
     * Log any exceptions thrown from service layer
     */
    @AfterThrowing(pointcut = "serviceMethods()", throwing = "exception")
    public void logAfterThrowing(JoinPoint joinPoint, Throwable exception) {
        String methodName = joinPoint.getSignature().toShortString();
        log.error("!!! Exception in Service Method: {} - Exception: {} - Message: {}",
                methodName, exception.getClass().getSimpleName(), exception.getMessage());
    }
}