-- Insert Users with BCrypt hashed passwords
-- Password for all users is "password123"
-- BCrypt hash: $2a$10$YLbZJY2hqL7lLz3SjH5WQuVfJY9H.0yVh1J3VgJL3L5NKaKzL4zKS

INSERT INTO users (username, password, role, enabled, created_at, updated_at) VALUES
                                                                                  ('admin', '$2a$10$YLbZJY2hqL7lLz3SjH5WQuVfJY9H.0yVh1J3VgJL3L5NKaKzL4zKS', 'ADMIN', true, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
                                                                                  ('staff1', '$2a$10$YLbZJY2hqL7lLz3SjH5WQuVfJY9H.0yVh1J3VgJL3L5NKaKzL4zKS', 'STAFF', true, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
                                                                                  ('student1', '$2a$10$YLbZJY2hqL7lLz3SjH5WQuVfJY9H.0yVh1J3VgJL3L5NKaKzL4zKS', 'STUDENT', true, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- Insert Planets
INSERT INTO planets (name, type, radius_km, mass_kg, orbital_period_days) VALUES
                                                                              ('Mercury', 'terrestrial', 2439.7, 3.3011e23, 87.97),
                                                                              ('Venus', 'terrestrial', 6051.8, 4.8675e24, 224.70),
                                                                              ('Earth', 'terrestrial', 6371.0, 5.97237e24, 365.26),
                                                                              ('Mars', 'terrestrial', 3389.5, 6.4171e23, 686.98),
                                                                              ('Jupiter', 'gas giant', 69911, 1.8982e27, 4332.59),
                                                                              ('Saturn', 'gas giant', 58232, 5.6834e26, 10759.22),
                                                                              ('Uranus', 'ice giant', 25362, 8.6810e25, 30688.5),
                                                                              ('Neptune', 'ice giant', 24622, 1.02413e26, 60182);

-- Insert Moons
-- Earth's moon
INSERT INTO moons (name, diameter_km, orbital_period_days, planet_id) VALUES
    ('Moon', 3474.8, 27.32, (SELECT planet_id FROM planets WHERE name = 'Earth'));

-- Mars' moons
INSERT INTO moons (name, diameter_km, orbital_period_days, planet_id) VALUES
                                                                          ('Phobos', 22.4, 0.319, (SELECT planet_id FROM planets WHERE name = 'Mars')),
                                                                          ('Deimos', 12.4, 1.263, (SELECT planet_id FROM planets WHERE name = 'Mars'));

-- Jupiter's major moons
INSERT INTO moons (name, diameter_km, orbital_period_days, planet_id) VALUES
                                                                          ('Io', 3643.2, 1.769, (SELECT planet_id FROM planets WHERE name = 'Jupiter')),
                                                                          ('Europa', 3121.6, 3.551, (SELECT planet_id FROM planets WHERE name = 'Jupiter')),
                                                                          ('Ganymede', 5268.2, 7.155, (SELECT planet_id FROM planets WHERE name = 'Jupiter')),
                                                                          ('Callisto', 4820.6, 16.689, (SELECT planet_id FROM planets WHERE name = 'Jupiter'));

-- Saturn's major moons
INSERT INTO moons (name, diameter_km, orbital_period_days, planet_id) VALUES
                                                                          ('Titan', 5149.5, 15.945, (SELECT planet_id FROM planets WHERE name = 'Saturn')),
                                                                          ('Rhea', 1527.6, 4.518, (SELECT planet_id FROM planets WHERE name = 'Saturn')),
                                                                          ('Iapetus', 1469.0, 79.330, (SELECT planet_id FROM planets WHERE name = 'Saturn')),
                                                                          ('Dione', 1123.0, 2.737, (SELECT planet_id FROM planets WHERE name = 'Saturn'));

-- Uranus' major moons
INSERT INTO moons (name, diameter_km, orbital_period_days, planet_id) VALUES
                                                                          ('Titania', 1577.8, 8.706, (SELECT planet_id FROM planets WHERE name = 'Uranus')),
                                                                          ('Oberon', 1522.8, 13.463, (SELECT planet_id FROM planets WHERE name = 'Uranus')),
                                                                          ('Umbriel', 1169.4, 4.144, (SELECT planet_id FROM planets WHERE name = 'Uranus')),
                                                                          ('Ariel', 1157.8, 2.520, (SELECT planet_id FROM planets WHERE name = 'Uranus'));

-- Neptune's major moons
INSERT INTO moons (name, diameter_km, orbital_period_days, planet_id) VALUES
                                                                          ('Triton', 2706.8, 5.877, (SELECT planet_id FROM planets WHERE name = 'Neptune')),
                                                                          ('Proteus', 420.0, 1.122, (SELECT planet_id FROM planets WHERE name = 'Neptune'));