-- Drop tables if they exist (for clean recreation)
DROP TABLE IF EXISTS moons;
DROP TABLE IF EXISTS planets;
DROP TABLE IF EXISTS users;

-- Create Users table
CREATE TABLE users (
                       user_id SERIAL PRIMARY KEY,
                       username VARCHAR(50) UNIQUE NOT NULL,
                       password VARCHAR(255) NOT NULL,
                       role VARCHAR(20) NOT NULL CHECK (role IN ('ADMIN', 'STAFF', 'STUDENT')),
                       enabled BOOLEAN NOT NULL DEFAULT true,
                       created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                       updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create Planets table
CREATE TABLE planets (
                         planet_id SERIAL PRIMARY KEY,
                         name VARCHAR(100) UNIQUE NOT NULL,
                         type VARCHAR(50) NOT NULL CHECK (type IN ('terrestrial', 'gas giant', 'ice giant')),
                         radius_km DECIMAL(10, 2) NOT NULL,
                         mass_kg DOUBLE PRECISION NOT NULL,
                         orbital_period_days DECIMAL(10, 2) NOT NULL
);

-- Create Moons table
CREATE TABLE moons (
                       moon_id SERIAL PRIMARY KEY,
                       name VARCHAR(100) NOT NULL,
                       diameter_km DECIMAL(10, 2) NOT NULL,
                       orbital_period_days DECIMAL(10, 4) NOT NULL,
                       planet_id INTEGER NOT NULL,
                       CONSTRAINT fk_planet
                           FOREIGN KEY (planet_id)
                               REFERENCES planets(planet_id)
                               ON DELETE CASCADE
);

-- Create indexes for better query performance
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_planets_name ON planets(name);
CREATE INDEX idx_moons_planet_id ON moons(planet_id);
CREATE INDEX idx_moons_name ON moons(name);