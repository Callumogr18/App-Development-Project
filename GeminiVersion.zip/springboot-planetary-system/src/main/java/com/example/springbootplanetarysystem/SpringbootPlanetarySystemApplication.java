package com.example.springbootplanetarysystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootPlanetarySystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootPlanetarySystemApplication.class, args);
	}
}