package com.example.springbootplanetarysystem.repository;

/**
 * Custom JPA Projection for retrieving specific fields of a Planet.
 */
public interface PlanetProjection {
    String getName();
    Double getMassKg();

}