package com.example.springbootplanetarysystem.controller;

import com.example.springbootplanetarysystem.dto.PlanetRequestDto;
import com.example.springbootplanetarysystem.entity.Planet;
import com.example.springbootplanetarysystem.repository.PlanetProjection;
import com.example.springbootplanetarysystem.service.PlanetService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/planets")
public class PlanetController {

    private final PlanetService planetService;

    public PlanetController(PlanetService planetService) {
        this.planetService = planetService;
    }

    // POST /api/planets (STAFF/ADMIN)
    @PostMapping
    public ResponseEntity<Planet> createPlanet(@Valid @RequestBody PlanetRequestDto dto) {
        Planet newPlanet = planetService.create(dto);
        return new ResponseEntity<>(newPlanet, HttpStatus.CREATED);
    }

    // GET /api/planets (STUDENT/STAFF/ADMIN)
    @GetMapping
    public ResponseEntity<List<Planet>> getAllPlanets() {
        return ResponseEntity.ok(planetService.findAll());
    }

    // GET /api/planets/{id} (STUDENT/STAFF/ADMIN)
    @GetMapping("/{id}")
    public ResponseEntity<Planet> getPlanetById(@PathVariable Long id) {
        return ResponseEntity.ok(planetService.findById(id));
    }

    // PUT /api/planets/{id} (STAFF/ADMIN)
    @PutMapping("/{id}")
    public ResponseEntity<Planet> updatePlanet(@PathVariable Long id, @Valid @RequestBody PlanetRequestDto dto) {
        Planet updatedPlanet = planetService.update(id, dto);
        return ResponseEntity.ok(updatedPlanet);
    }

    // DELETE /api/planets/{id} (STAFF/ADMIN)
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deletePlanet(@PathVariable Long id) {
        planetService.delete(id);
    }

    // GET /api/planets/type/{type} (STUDENT/STAFF/ADMIN)
    @GetMapping("/type/{type}")
    public ResponseEntity<List<Planet>> getPlanetsByType(@PathVariable String type) {
        return ResponseEntity.ok(planetService.findByType(type));
    }

    // GET /api/planets/projection (STUDENT/STAFF/ADMIN)
    @GetMapping("/projection")
    public ResponseEntity<List<PlanetProjection>> getPlanetProjection() {
        return ResponseEntity.ok(planetService.getPlanetProjection());
    }
}