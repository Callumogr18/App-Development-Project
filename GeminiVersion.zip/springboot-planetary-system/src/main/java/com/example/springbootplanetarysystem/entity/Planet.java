package com.example.springbootplanetarysystem.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.HashSet;
import java.util.Set;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Planet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long planetId;

    @Column(unique = true, nullable = false)
    private String name;

    @Column(nullable = false)
    private String type;

    private Double radiusKm;
    private Double massKg;
    private Double orbitalPeriodDays;

    @OneToMany(mappedBy = "planet", cascade = CascadeType.ALL, orphanRemoval = true)
    @ToString.Exclude // Exclude from toString to prevent logging conflicts
    @JsonManagedReference // 👈 Tells Jackson to serialize this collection (the children)
    private Set<Moon> moons = new HashSet<>();
}