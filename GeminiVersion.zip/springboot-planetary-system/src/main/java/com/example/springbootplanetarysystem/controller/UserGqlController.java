package com.example.springbootplanetarysystem.controller;

import com.example.springbootplanetarysystem.dto.UserGqlInput;
import com.example.springbootplanetarysystem.entity.User;
import com.example.springbootplanetarysystem.service.UserService;
import jakarta.validation.Valid;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;

import java.util.Optional;

@Controller
public class UserGqlController {

    private final UserService userService;

    public UserGqlController(UserService userService) {
        this.userService = userService;
    }

    // Query: findUserById(id: ID): User (ADMIN only)
    @QueryMapping
    @PreAuthorize("hasRole('ADMIN')")
    public Optional<User> findUserById(@Argument Long id) {
        return userService.findUserById(id);
    }

    // Mutation: createUser(userInput: UserInput): User (ADMIN only)
    @MutationMapping
    @PreAuthorize("hasRole('ADMIN')")
    public User createUser(@Valid @Argument UserGqlInput userInput) {
        return userService.createUser(
                userInput.getUsername(),
                userInput.getPassword(),
                userInput.getRole()
        );
    }
}