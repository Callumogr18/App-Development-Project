package com.example.springbootplanetarysystem.config;

import com.example.springbootplanetarysystem.entity.Moon;
import com.example.springbootplanetarysystem.entity.Planet;
import com.example.springbootplanetarysystem.entity.User;
import com.example.springbootplanetarysystem.entity.UserRole;
import com.example.springbootplanetarysystem.repository.MoonRepository;
import com.example.springbootplanetarysystem.repository.PlanetRepository;
import com.example.springbootplanetarysystem.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Set;

@Configuration
public class DataLoader {

    @Bean
    public CommandLineRunner loadData(
            UserRepository userRepository,
            PlanetRepository planetRepository, // Inject PlanetRepository
            MoonRepository moonRepository,     // Inject MoonRepository
            PasswordEncoder passwordEncoder) {

        return args -> {
            // --- 1. Load USERS ---
            userRepository.save(new User(null, "admin", passwordEncoder.encode("adminpass"), UserRole.ADMIN, true, null));
            userRepository.save(new User(null, "staff", passwordEncoder.encode("staffpass"), UserRole.STAFF, true, null));
            userRepository.save(new User(null, "student", passwordEncoder.encode("studentpass"), UserRole.STUDENT, true, null));

            // --- 2. Load PLANETS ---
            Planet earth = planetRepository.save(new Planet(null, "Earth", "terrestrial", 6371.0, 5.972e24, 365.25, null));
            Planet jupiter = planetRepository.save(new Planet(null, "Jupiter", "gas giant", 69911.0, 1.898e27, 4332.6, null));
            Planet mars = planetRepository.save(new Planet(null, "Mars", "terrestrial", 3389.5, 6.39e23, 687.0, null));

            // --- 3. Load MOONS ---
            moonRepository.save(new Moon(null, "Luna", 3474.8, 27.3, earth));
            moonRepository.save(new Moon(null, "Io", 3643.0, 1.77, jupiter));
            moonRepository.save(new Moon(null, "Europa", 3121.6, 3.55, jupiter));
            moonRepository.save(new Moon(null, "Phobos", 22.4, 0.32, mars));
            moonRepository.save(new Moon(null, "Deimos", 12.4, 1.26, mars));

            // IMPORTANT: If you want the 'moons' set on the Planet entity to be updated,
            // you should reload or manage the relationship bi-directionally,
            // but for simple testing, saving the Moons (which sets the FK) is usually sufficient.

            // Output confirmation
            System.out.println("Initial users, planets, and moons loaded successfully.");
        };
    }
}