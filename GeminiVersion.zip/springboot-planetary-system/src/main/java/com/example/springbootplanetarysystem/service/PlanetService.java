package com.example.springbootplanetarysystem.service;

import com.example.springbootplanetarysystem.dto.PlanetRequestDto;
import com.example.springbootplanetarysystem.entity.Planet;
import com.example.springbootplanetarysystem.exception.ResourceNotFoundException;
import com.example.springbootplanetarysystem.repository.PlanetProjection;
import com.example.springbootplanetarysystem.repository.PlanetRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PlanetService {

    private final PlanetRepository planetRepository;

    public PlanetService(PlanetRepository planetRepository) {
        this.planetRepository = planetRepository;
    }

    public List<Planet> findAll() {
        return planetRepository.findAllWithMoonsEagerly();
    }

    public Planet findById(Long id) {
        return planetRepository.findByIdWithMoonsEagerly(id)
                .orElseThrow(() -> new ResourceNotFoundException("Planet not found with id: " + id));
    }

    public Planet create(PlanetRequestDto dto) {
        Planet planet = new Planet(
                null,
                dto.getName(),
                dto.getType(),
                dto.getRadiusKm(),
                dto.getMassKg(),
                dto.getOrbitalPeriodDays(),
                null
        );
        return planetRepository.save(planet);
    }

    public Planet update(Long id, PlanetRequestDto dto) {
        Planet planet = findById(id);
        planet.setName(dto.getName());
        planet.setType(dto.getType());
        planet.setRadiusKm(dto.getRadiusKm());
        planet.setMassKg(dto.getMassKg());
        planet.setOrbitalPeriodDays(dto.getOrbitalPeriodDays());
        return planetRepository.save(planet);
    }

    public void delete(Long id) {
        if (!planetRepository.existsById(id)) {
            throw new ResourceNotFoundException("Planet not found with id: " + id);
        }
        planetRepository.deleteById(id);
    }

    public List<Planet> findByType(String type) {
        return planetRepository.findByTypeIgnoreCase(type);
    }

    public List<PlanetProjection> getPlanetProjection() {
        return planetRepository.findAllProjectedBy();
    }
}