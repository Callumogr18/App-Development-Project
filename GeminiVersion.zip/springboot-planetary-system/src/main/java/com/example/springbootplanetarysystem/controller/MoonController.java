package com.example.springbootplanetarysystem.controller;

import com.example.springbootplanetarysystem.dto.MoonRequestDto;
import com.example.springbootplanetarysystem.entity.Moon;
import com.example.springbootplanetarysystem.service.MoonService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/moons")
public class MoonController {

    private final MoonService moonService;

    public MoonController(MoonService moonService) {
        this.moonService = moonService;
    }

    // POST /api/moons (STAFF/ADMIN)
    @PostMapping
    public ResponseEntity<Moon> createMoon(@Valid @RequestBody MoonRequestDto dto) {
        Moon newMoon = moonService.create(dto);
        return new ResponseEntity<>(newMoon, HttpStatus.CREATED);
    }

    // GET /api/moons (STUDENT/STAFF/ADMIN)
    @GetMapping
    public ResponseEntity<List<Moon>> getAllMoons() {
        return ResponseEntity.ok(moonService.findAll());
    }

    // GET /api/moons/{id} (STUDENT/STAFF/ADMIN)
    @GetMapping("/{id}")
    public ResponseEntity<Moon> getMoonById(@PathVariable Long id) {
        return ResponseEntity.ok(moonService.findById(id));
    }

    // DELETE /api/moons/{id} (STAFF/ADMIN)
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteMoon(@PathVariable Long id) {
        moonService.delete(id);
    }

    // GET /api/moons/by-planet/{planetName} (STUDENT/STAFF/ADMIN)
    @GetMapping("/by-planet/{planetName}")
    public ResponseEntity<List<Moon>> getMoonsByPlanetName(@PathVariable String planetName) {
        return ResponseEntity.ok(moonService.findMoonsByPlanetName(planetName));
    }

    // GET /api/moons/count/{planetId} (STUDENT/STAFF/ADMIN)
    @GetMapping("/count/{planetId}")
    public ResponseEntity<Long> countMoonsByPlanetId(@PathVariable Long planetId) {
        return ResponseEntity.ok(moonService.countMoonsByPlanetId(planetId));
    }
}