package com.example.springbootplanetarysystem.repository;

import com.example.springbootplanetarysystem.entity.Moon;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface MoonRepository extends JpaRepository<Moon, Long> {

    // Custom JPA Query to find moons by the linked planet's name
    @Query("SELECT m FROM Moon m JOIN m.planet p WHERE p.name = :planetName")
    List<Moon> findMoonsByPlanetName(@Param("planetName") String planetName);

    // Custom aggregate JPA query to count moons by planet ID
    @Query("SELECT COUNT(m) FROM Moon m WHERE m.planet.planetId = :planetId")
    Long countMoonsByPlanetId(@Param("planetId") Long planetId);
}