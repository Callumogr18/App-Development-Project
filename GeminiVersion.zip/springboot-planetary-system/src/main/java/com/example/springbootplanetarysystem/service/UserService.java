package com.example.springbootplanetarysystem.service;

import com.example.springbootplanetarysystem.entity.User;
import com.example.springbootplanetarysystem.entity.UserRole;
import com.example.springbootplanetarysystem.exception.ResourceNotFoundException;
import com.example.springbootplanetarysystem.repository.UserRepository;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService implements UserDetailsService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // --- UserDetailsService Implementation ---
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with username: " + username));

        // Map UserRole to GrantedAuthority
        List<GrantedAuthority> authorities = List.of(new SimpleGrantedAuthority("ROLE_" + user.getRole().name()));

        return new org.springframework.security.core.userdetails.User(
                user.getUsername(),
                user.getPassword(),
                user.getEnabled(),
                true, true, true,
                authorities);
    }

    // --- GraphQL Methods ---
    public User createUser(String username, String rawPassword, UserRole role) {
        String encodedPassword = passwordEncoder.encode(rawPassword);
        User newUser = new User(null, username, encodedPassword, role, true, null);
        return userRepository.save(newUser);
    }

    public Optional<User> findUserById(Long id) {
        return userRepository.findById(id);
    }
}