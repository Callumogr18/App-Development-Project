package com.example.springbootplanetarysystem.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Aspect
@Component
public class LoggingAspect {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    // 1. Pointcut: Executing all methods in the service layer
    @Pointcut("within(com.example.springbootplanetarysystem.service..*)")
    public void serviceLayerExecution() {}

    // Advice: Log entry and exit of all methods in the service layer
    @Around("serviceLayerExecution()")
    public Object logServiceMethodAround(ProceedingJoinPoint joinPoint) throws Throwable {
        long start = System.currentTimeMillis();
        String className = joinPoint.getSignature().getDeclaringTypeName();
        String methodName = joinPoint.getSignature().getName();

        log.info("--> Entering {}.{}() with arguments = {}", className, methodName, Arrays.toString(joinPoint.getArgs()));

        try {
            Object result = joinPoint.proceed();
            long elapsedTime = System.currentTimeMillis() - start;
            log.info("<-- Exiting {}.{}() executed in {}ms, result: {}", className, methodName, elapsedTime, result);
            return result;
        } catch (IllegalArgumentException e) {
            log.error("!!! Illegal argument: {} in {}.{}()", Arrays.toString(joinPoint.getArgs()), className, methodName);
            throw e;
        }
    }

    // 2. Pointcut: Executing any REST POST or PUT (Mutations) requests in the controller layer
    @Pointcut("execution(* com.example.springbootplanetarysystem.controller.*Controller.create*(..)) || execution(* com.example.springbootplanetarysystem.controller.*Controller.update*(..))")
    public void mutationControllerMethods() {}

    // Advice: Log security and request body before mutation methods
    @Before("mutationControllerMethods()")
    public void logControllerMutation(JoinPoint joinPoint) {
        log.debug("### REST Mutation Call: {} with arguments: {}", joinPoint.getSignature().toShortString(), Arrays.toString(joinPoint.getArgs()));
        log.debug("### Security Context Check: Current user is authenticated for modification.");
    }

    // 3. Pointcut: For specific custom repository methods (using @Query)
    @Pointcut("execution(* com.example.springbootplanetarysystem.repository.MoonRepository.findMoonsByPlanetName(..))")
    public void customJPARepositoryQuery() {}

    // Advice: Log when a custom JPA query is about to run
    @Before("customJPARepositoryQuery()")
    public void logCustomQueryExecution(JoinPoint joinPoint) {
        String planetName = (String) joinPoint.getArgs()[0];
        log.info("@@@ Custom JPA Query Execution: Finding moons for Planet Name: {}", planetName);
    }
}