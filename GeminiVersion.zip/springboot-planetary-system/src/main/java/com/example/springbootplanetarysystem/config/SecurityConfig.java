package com.example.springbootplanetarysystem.config;

import com.example.springbootplanetarysystem.service.UserService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import static org.springframework.security.config.Customizer.withDefaults;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    // --- BEANS FOR DEPENDENCY RESOLUTION ---

    @Bean
    public PasswordEncoder passwordEncoder() {
        // Required for BCrypt hashing of user passwords
        return new BCryptPasswordEncoder();
    }

    // This method now takes UserService and PasswordEncoder as parameters,
    // breaking the circular dependency.
    @Bean
    public DaoAuthenticationProvider authenticationProvider(
            UserService userService,
            PasswordEncoder passwordEncoder
    ) {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userService);
        authProvider.setPasswordEncoder(passwordEncoder);
        return authProvider;
    }

    // --- SECURITY FILTER CHAIN (RBAC Configuration) ---

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(AbstractHttpConfigurer::disable)
                .authorizeHttpRequests(authorize -> authorize
                        // 1. PUBLIC ACCESS (Development/Metadata Tools)
                        .requestMatchers(
                                "/h2-console/**",
                                "/swagger-ui.html",
                                "/swagger-ui/**",
                                "/v3/api-docs/**",
                                "/actuator/**",
                                "/graphiql" // Allowing access to the GraphQL IDE tool
                        ).permitAll()

                        // 2. GRAPHQL ACCESS (The actual data endpoint)
                        // We enforce ADMIN role here as per requirement (for the GQL controller).
                        .requestMatchers("/graphql").hasRole("ADMIN")

                        // 3. PLANETS REST Endpoints (STUDENT/STAFF/ADMIN)
                        .requestMatchers(HttpMethod.POST, "/api/planets").hasAnyRole("ADMIN", "STAFF")
                        .requestMatchers(HttpMethod.PUT, "/api/planets/**").hasAnyRole("ADMIN", "STAFF")
                        .requestMatchers(HttpMethod.DELETE, "/api/planets/**").hasAnyRole("ADMIN", "STAFF")
                        // Read access for everyone
                        .requestMatchers(HttpMethod.GET, "/api/planets/**").hasAnyRole("ADMIN", "STAFF", "STUDENT")

                        // 4. MOONS REST Endpoints (STUDENT/STAFF/ADMIN)
                        .requestMatchers(HttpMethod.POST, "/api/moons").hasAnyRole("ADMIN", "STAFF")
                        .requestMatchers(HttpMethod.DELETE, "/api/moons/**").hasAnyRole("ADMIN", "STAFF")
                        // Read access for everyone
                        .requestMatchers(HttpMethod.GET, "/api/moons/**").hasAnyRole("ADMIN", "STAFF", "STUDENT")

                        // Any other request must be authenticated
                        .anyRequest().authenticated()
                )
                .headers(headers -> headers.frameOptions().disable()) // Required for H2 console
                .httpBasic(withDefaults()); // Enables Basic Authentication

        return http.build();
    }
}