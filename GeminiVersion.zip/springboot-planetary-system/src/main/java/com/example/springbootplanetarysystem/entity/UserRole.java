package com.example.springbootplanetarysystem.entity;

public enum UserRole {
    ADMIN, STAFF, STUDENT
}