package com.example.springbootplanetarysystem.repository;

import com.example.springbootplanetarysystem.entity.Planet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query; // 👈 Don't forget this import!
import java.util.List;
import java.util.Optional;

public interface PlanetRepository extends JpaRepository<Planet, Long> {

    // 💡 FIX: Custom method to EAGERLY load Moons with Planets
    // This uses a JOIN FETCH to load the bidirectional relationship in one query,
    // eliminating the concurrent modification error during serialization.
    @Query("SELECT p FROM Planet p LEFT JOIN FETCH p.moons")
    List<Planet> findAllWithMoonsEagerly();

    // --- Existing Custom Queries ---
    @Query("SELECT p FROM Planet p LEFT JOIN FETCH p.moons WHERE p.planetId = :id")
    Optional<Planet> findByIdWithMoonsEagerly(Long id);
    // Custom derived query for filtering
    List<Planet> findByTypeIgnoreCase(String type);

    // Custom projection query (requires a PlanetProjection interface definition)
    List<PlanetProjection> findAllProjectedBy();
}