package com.example.springbootplanetarysystem.service;

import com.example.springbootplanetarysystem.dto.MoonRequestDto;
import com.example.springbootplanetarysystem.entity.Moon;
import com.example.springbootplanetarysystem.entity.Planet;
import com.example.springbootplanetarysystem.exception.ResourceNotFoundException;
import com.example.springbootplanetarysystem.repository.MoonRepository;
import com.example.springbootplanetarysystem.repository.PlanetRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class MoonService {

    private final MoonRepository moonRepository;
    private final PlanetRepository planetRepository;

    public MoonService(MoonRepository moonRepository, PlanetRepository planetRepository) {
        this.moonRepository = moonRepository;
        this.planetRepository = planetRepository;
    }

    public List<Moon> findAll() {
        return moonRepository.findAll();
    }

    public Moon findById(Long id) {
        return moonRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Moon not found with id: " + id));
    }

    public Moon create(MoonRequestDto dto) {
        Planet planet = planetRepository.findById(dto.getPlanetId())
                .orElseThrow(() -> new ResourceNotFoundException("Planet not found with id: " + dto.getPlanetId()));

        Moon moon = new Moon(
                null,
                dto.getName(),
                dto.getDiameterKm(),
                dto.getOrbitalPeriodDays(),
                planet
        );
        return moonRepository.save(moon);
    }

    public void delete(Long id) {
        if (!moonRepository.existsById(id)) {
            throw new ResourceNotFoundException("Moon not found with id: " + id);
        }
        moonRepository.deleteById(id);
    }

    public List<Moon> findMoonsByPlanetName(String planetName) {
        List<Moon> moons = moonRepository.findMoonsByPlanetName(planetName);
        if (moons.isEmpty()) {
            // Optional: You could check for the Planet's existence first if you want a different error message
            // for "Planet not found" vs "Planet found but no moons"
        }
        return moons;
    }

    public Long countMoonsByPlanetId(Long planetId) {
        // Check if planet exists for cleaner error handling
        if (!planetRepository.existsById(planetId)) {
            throw new ResourceNotFoundException("Planet not found with id: " + planetId);
        }
        return moonRepository.countMoonsByPlanetId(planetId);
    }
}